SELECT disablePackage('sample_scripts');
