<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>DisplayItemLocations</name>
    <message>
        <source>Display Item Locations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatically Update</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Address Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>_Form</name>
    <message>
        <source>File Control Demo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> WriteText:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ReadText:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home Path:  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Root Path:    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Name:   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make Path: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Path</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addButton</name>
    <message>
        <source>Something Happened</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Random button was clicked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Random</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addressCoordinates</name>
    <message>
        <source>GPS Coordinates for Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Longitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addressDialog</name>
    <message>
        <source>Address Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addressQBE</name>
    <message>
        <source>Query For Addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search Criteria:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QDialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QMainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Matching Addresses:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit in a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View in a</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ccvoid</name>
    <message>
        <source>No Credit Card Processor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not get a credit card processor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot Void</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This transaction cannot be voided a second time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A database error occurred: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error during data transfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;There was a network error trying to post the transaction: %1.Look up this error code at  &lt;a&gt;http://doc.trolltech.com/4.4/qnetworkreply.html#NetworkError-enum&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error returned from A.N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Declined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The void transaction was declined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The void transaction received an error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The void transaction received an unknown approval value: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error querying the database: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transaction Complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The ccpay table has been updated after completing the Void transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transactions which can be voided:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Void Selected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu_executeQueryExample</name>
    <message>
        <source>No exchange rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 has no exchange rate for today.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was a database error while checking for exchange rates during startup:%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>itemSiteViewItem</name>
    <message>
        <source>Item Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loc. Controlled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Control Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View Item Details for Item Sites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items at this site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item Site</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sample_scripts</name>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>scriptCC</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Transaction:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prior Transaction:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cards:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Charge a Pre-Auth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Void</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Authorize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Charge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Credit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CVV:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Order:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sohist</name>
    <message>
        <source>New Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Results:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Line Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sohist0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>weatherForAddress</name>
    <message>
        <source>Network Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The request for weather information returned error %1&lt;br&gt;%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conditions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>As of:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>xtreewidgetdemo</name>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processing Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
