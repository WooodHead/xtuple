INSERT INTO priv (
  priv_module, priv_name, priv_descrip
) VALUES (
  'Accounting', 'ProcessCreditCards',
  'Can Process Credit Card Transactions'
);
