ALTER TABLE char ADD COLUMN char_employees BOOLEAN DEFAULT false;
