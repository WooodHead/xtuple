
ALTER TABLE itemloc ADD COLUMN itemloc_warrpurc DATE;

