SELECT setMetric('ServerVersion', '4.0.0RC');
