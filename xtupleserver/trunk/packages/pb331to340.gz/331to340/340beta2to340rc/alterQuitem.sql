
CREATE INDEX quitem_quhead_id_key ON quitem(quitem_quhead_id);

