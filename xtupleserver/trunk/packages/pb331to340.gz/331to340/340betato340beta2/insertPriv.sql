INSERT INTO priv ( priv_module , priv_name, priv_descrip ) VALUES ('System' , 'MaintainStates' , 'User is allowed to edit the list of States and Provinces' );

