SELECT dropIfExists('FUNCTION', 'closeWo(INTEGER, BOOLEAN, BOOLEAN)', 'public');
