
SELECT setMetric('ServerVersion', '3.4.0');

