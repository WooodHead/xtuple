 SELECT dropIfExists('FUNCTION', 'postmiscconsumption(integer, numeric, integer, integer, integer, numeric, text, text)', 'public');
 SELECT dropIfExists('FUNCTION', 'postmiscproduction(integer, numeric, boolean, text, text)', 'public');

