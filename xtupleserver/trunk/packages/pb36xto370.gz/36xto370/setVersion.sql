SELECT setMetric('ServerVersion', '3.7.0');

