ALTER TABLE flhead ADD COLUMN flhead_notes text DEFAULT '';
