
ALTER TABLE classcode ADD COLUMN classcode_creator TEXT;
ALTER TABLE classcode ADD COLUMN classcode_created TIMESTAMP;
ALTER TABLE classcode ADD COLUMN classcode_modifier TEXT;
ALTER TABLE classcode ADD COLUMN classcode_modified TIMESTAMP;
ALTER TABLE classcode ADD COLUMN classcode_type TEXT;

