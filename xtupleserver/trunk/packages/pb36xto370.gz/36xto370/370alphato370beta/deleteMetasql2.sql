delete from metasql where metasql_group='workOrderSoStatus' and metasql_name='detail' and metasql_grade=0;
delete from metasql where metasql_group='customerInformationExport' and metasql_name='detail' and metasql_grade=0;
delete from metasql where metasql_group='products' and metasql_name='items' and metasql_grade=0;