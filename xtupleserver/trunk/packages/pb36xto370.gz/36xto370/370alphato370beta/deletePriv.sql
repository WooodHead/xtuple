DELETE FROM priv WHERE priv_name='MaintainProspects';
DELETE FROM priv WHERE priv_name='ViewProspects';
