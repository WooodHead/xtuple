alter table char add column char_type int not null default (0);
alter table char add column char_order int not null default (0);