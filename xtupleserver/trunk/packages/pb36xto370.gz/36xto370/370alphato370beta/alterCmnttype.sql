
ALTER TABLE cmnttype ADD COLUMN cmnttype_order INTEGER;

