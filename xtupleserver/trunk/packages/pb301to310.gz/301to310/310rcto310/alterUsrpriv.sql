ALTER TABLE usrpriv DROP CONSTRAINT usrpriv_usrpriv_priv_id_fkey;
