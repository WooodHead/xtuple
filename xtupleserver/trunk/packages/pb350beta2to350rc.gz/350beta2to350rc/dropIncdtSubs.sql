
SELECT dropIfExists('TABLE', 'incdt_subs');

