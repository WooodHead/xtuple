SELECT setMetric('ServerVersion', '.3.8.0Alpha-3.8.0Beta');

