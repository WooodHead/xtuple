ALTER TABLE bankrecitem ADD COLUMN bankrecitem_curr_rate NUMERIC;
