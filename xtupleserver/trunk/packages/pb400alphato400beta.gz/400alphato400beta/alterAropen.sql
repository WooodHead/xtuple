alter table aropen alter column aropen_discount set default false;
alter table aropen alter column aropen_cobmisc_id set default -1;
alter table aropen alter column aropen_salescat_id set default -1;
alter table aropen alter column aropen_commission_paid set default false;
alter table aropen alter column aropen_paid set default 0;


