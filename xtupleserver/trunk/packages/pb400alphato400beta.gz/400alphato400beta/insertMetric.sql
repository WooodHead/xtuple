insert into metric (metric_name, metric_value) values ('InterfaceAPToGL', 't');
insert into metric (metric_name, metric_value) values ('InterfaceARToGL', 't');
