SELECT setMetric('ACHSupported',     't');
