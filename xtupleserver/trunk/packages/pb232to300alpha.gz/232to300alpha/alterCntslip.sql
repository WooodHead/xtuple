
ALTER TABLE cntslip ADD COLUMN cntslip_lotserial_warrpurc DATE;

