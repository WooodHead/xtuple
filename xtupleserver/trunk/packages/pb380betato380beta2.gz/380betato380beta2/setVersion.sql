SELECT setMetric('ServerVersion', '3.8.0Beta2');
