SELECT dropIfExists('TRIGGER', 'prjTrigger');
SELECT dropIfExists('FUNCTION', '_prjTrigger()');