ALTER TABLE glseries ADD COLUMN glseries_misc_id INTEGER;
