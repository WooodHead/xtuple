select dropIfExists('VIEW','billingeditlist');
select dropIfExists('VIEW','voucheringeditlist');