
ALTER TABLE pr ADD COLUMN pr_releasenote text;

