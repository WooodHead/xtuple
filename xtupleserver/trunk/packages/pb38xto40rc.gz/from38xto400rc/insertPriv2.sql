insert into priv (priv_module, priv_name, priv_descrip) values ('Accounting', 'PostFrozenPeriod', 'Can Post into frozen Accounting Period');
