SELECT createColumn('public', 'prj', 'prj_crmacct_id', 'INTEGER', NULL,
                    TRUE, 'crmacct', 'crmacct_id');
SELECT createColumn('public', 'prj', 'prj_cntct_id', 'INTEGER', NULL,
                    TRUE, 'cntct', 'cntct_id');
