alter table apopen alter column apopen_discount set default false;
alter table apopen alter column apopen_paid set default 0;


