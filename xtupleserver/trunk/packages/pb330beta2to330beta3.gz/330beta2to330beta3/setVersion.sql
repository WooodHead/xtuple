
SELECT setMetric('ServerVersion', '3.3.0Beta3');

