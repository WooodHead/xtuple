
INSERT INTO source (source_module, source_name, source_descrip) VALUES ('CRM', 'TD', 'Todo Item');
INSERT INTO source (source_module, source_name, source_descrip) VALUES ('CRM', 'TA', 'Tasks');

