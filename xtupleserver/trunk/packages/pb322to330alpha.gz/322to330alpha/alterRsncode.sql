
ALTER TABLE rsncode ADD COLUMN rsncode_doctype TEXT;


