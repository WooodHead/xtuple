INSERT INTO taxtype (taxtype_name, taxtype_descrip, taxtype_sys)
VALUES('Adjustment', 'System Defined Adjustment Tax Type. DO NOT CHANGE.', TRUE);