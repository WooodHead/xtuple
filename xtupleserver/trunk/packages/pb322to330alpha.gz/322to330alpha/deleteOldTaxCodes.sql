
DELETE FROM tax WHERE tax_taxclass_id IS NULL;

