
SELECT dropIfExists('CONSTRAINT', 'incdtcat_incdtcat_ediprofile_id_fkey');

