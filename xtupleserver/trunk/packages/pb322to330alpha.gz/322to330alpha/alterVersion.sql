
DELETE FROM metric WHERE metric_name = 'DBVersion';
DELETE FROM metric WHERE metric_name = 'OpenMFGServerVersion';

