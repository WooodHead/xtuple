
ALTER TABLE vohead ADD COLUMN vohead_notes TEXT;


