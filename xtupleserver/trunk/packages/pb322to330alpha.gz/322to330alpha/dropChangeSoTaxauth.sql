
DROP FUNCTION changesotaxauth(integer, integer);

