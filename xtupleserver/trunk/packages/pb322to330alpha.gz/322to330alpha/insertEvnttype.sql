insert into evnttype ( evnttype_name, evnttype_descrip, evnttype_module )
              values ('CostExceedsMaxDesired' , 'Cost Exceeds Max Desired', 'P/D' );
