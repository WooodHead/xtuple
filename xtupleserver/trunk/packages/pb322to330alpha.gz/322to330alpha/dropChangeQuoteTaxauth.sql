
DROP FUNCTION changequotetaxauth(integer, integer);

