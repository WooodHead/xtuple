
ALTER TABLE cmitem ADD COLUMN cmitem_raitem_id INTEGER;

