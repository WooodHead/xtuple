ALTER TABLE checkhead ADD checkhead_ach_batch TEXT;
