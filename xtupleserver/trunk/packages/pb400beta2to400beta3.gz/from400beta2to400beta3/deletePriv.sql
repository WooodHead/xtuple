DELETE FROM priv WHERE priv_name='ViewAllIncidentHistory';
