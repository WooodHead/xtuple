SELECT dropIfExists('VIEW', 'ipsitem', 'public', true);
SELECT dropIfExists('VIEW', 'itemprices', 'public', true);
