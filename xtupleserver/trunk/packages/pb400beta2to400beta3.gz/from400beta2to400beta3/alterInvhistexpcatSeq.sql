REVOKE ALL ON SEQUENCE invhistexpcat_invhistexpcat_id_seq FROM PUBLIC;
GRANT  ALL ON SEQUENCE invhistexpcat_invhistexpcat_id_seq TO xtrole;
GRANT  ALL ON SEQUENCE invhistexpcat_invhistexpcat_id_seq TO admin;
