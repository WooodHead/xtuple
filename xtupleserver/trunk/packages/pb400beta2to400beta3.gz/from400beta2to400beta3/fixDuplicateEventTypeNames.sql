
CREATE FUNCTION fixDuplicateEventTypeNames() RETURNS INTEGER AS $$
DECLARE
  _badids  INTEGER[];
  _tmp     INTEGER := 0;
  _r       RECORD;
  _result  INTEGER := 0;
BEGIN
  FOR _r IN SELECT COUNT(*), evnttype_name, MIN(evnttype_id) AS keep
              FROM evnttype
            GROUP BY evnttype_name
            HAVING COUNT(*) > 1
  LOOP
    UPDATE evntnot SET evntnot_evnttype_id = _r.keep
     WHERE evntnot_evnttype_id IN (SELECT unnest(_badids));
    GET DIAGNOSTICS _tmp = ROW_COUNT;
    _result := _result + _tmp;

    UPDATE evntlog SET evntlog_evnttype_id = _r.keep
     WHERE evntlog_evnttype_id IN (SELECT unnest(_badids));
    GET DIAGNOSTICS _tmp = ROW_COUNT;
    _result := _result + _tmp;

    DELETE FROM evnttype
     WHERE evnttype_name = _r.evnttype_name
       AND evnttype_id != _r.keep;
    GET DIAGNOSTICS _tmp = ROW_COUNT;
    _result := _result + _tmp;
  END LOOP;

  RETURN _result;
END;
$$ LANGUAGE PLPGSQL;

SELECT fixDuplicateEventTypeNames();

DROP FUNCTION IF EXISTS fixDuplicateEventTypeNames();
