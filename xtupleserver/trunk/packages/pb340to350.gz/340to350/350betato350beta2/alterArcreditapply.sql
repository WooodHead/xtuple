ALTER TABLE arcreditapply ADD column arcreditapply_reftype text;
ALTER TABLE arcreditapply ADD column arcreditapply_ref_id integer;