INSERT INTO priv (priv_name, priv_descrip, priv_module
       ) VALUES ('ExportXML', 'Can Export XML Files', 'System');

