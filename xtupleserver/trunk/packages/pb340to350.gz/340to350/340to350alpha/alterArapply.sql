
CREATE INDEX arapply_arapply_target_docnumber_idx ON arapply ( arapply_target_docnumber );

