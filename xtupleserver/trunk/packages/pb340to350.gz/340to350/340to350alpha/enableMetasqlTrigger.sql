ALTER TABLE metasql ENABLE TRIGGER metasqlAlterTrigger;
