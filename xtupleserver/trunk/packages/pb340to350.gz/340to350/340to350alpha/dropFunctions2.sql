
SELECT dropifexists('FUNCTION','calcqtyreq(integer,numeric,numeric,numeric)');
SELECT dropifexists('FUNCTION','calcqtyreq(integer,integer,numeric,numeric,numeric)');
SELECT dropifexists('FUNCTION','explodesummarizedbom(integer,integer,integer,integer,integer,numeric,date,date)');
