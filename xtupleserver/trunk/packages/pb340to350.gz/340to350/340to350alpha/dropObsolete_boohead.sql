SELECT dropIfExists('TABLE', 'obsolete_boohead');
