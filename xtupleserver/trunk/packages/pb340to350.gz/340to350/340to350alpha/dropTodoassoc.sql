SELECT dropIfExists('TABLE', 'todoassoc');
