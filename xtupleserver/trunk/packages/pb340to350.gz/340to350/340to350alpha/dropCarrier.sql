SELECT dropIfExists('TABLE', 'carrier');
