
SELECT dropifexists('FUNCTION','createGLReport (integer)' );
