SELECT dropIfExists('TABLE', 'armemo');
