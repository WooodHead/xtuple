
SELECT dropifexists('FUNCTION','_itemimageTrigger()' );
SELECT dropifexists('FUNCTION','_itemfileTrigger()' );

