
SELECT dropifexists('VIEW','salesquoteitem');
