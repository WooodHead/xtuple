ALTER TABLE metasql DISABLE TRIGGER metasqlAlterTrigger;
