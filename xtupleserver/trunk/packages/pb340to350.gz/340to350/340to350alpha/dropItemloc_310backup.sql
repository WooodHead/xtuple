SELECT dropIfExists('TABLE', 'itemloc_310backup');
