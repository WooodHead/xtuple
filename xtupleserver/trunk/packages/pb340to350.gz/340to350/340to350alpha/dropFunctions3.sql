
SELECT dropifexists('FUNCTION','invReceiptIssueToWomatl(INTEGER, NUMERIC, TEXT, INTEGER, TEXT)' );