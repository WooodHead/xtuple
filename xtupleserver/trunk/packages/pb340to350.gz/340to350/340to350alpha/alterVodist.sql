ALTER TABLE vodist ADD COLUMN vodist_notes TEXT;
