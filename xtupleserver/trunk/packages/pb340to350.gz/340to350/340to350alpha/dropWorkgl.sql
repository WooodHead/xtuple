SELECT dropIfExists('TABLE', 'workglhead');
SELECT dropIfExists('TABLE', 'workglitem');
SELECT dropIfExists('TABLE', 'workgltotal');
SELECT dropIfExists('TABLE', 'workgltotaleq');
