SELECT dropIfExists('TABLE', 'obsolete_poheadcol');
