SELECT dropIfExists('TABLE', 'curr');
