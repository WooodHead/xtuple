-- Sould be nothing here, but make sure this table is clear anyway
DELETE FROM itemlocdist;