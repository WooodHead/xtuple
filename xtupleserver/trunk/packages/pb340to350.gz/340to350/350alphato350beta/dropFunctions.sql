
SELECT dropifexists('FUNCTION', 'postpurchaseorder(INTEGER)');