ALTER TABLE cashrcpt ALTER COLUMN cashrcpt_distdate SET DEFAULT current_date;
