REVOKE ALL ON SEQUENCE file_file_id_seq FROM PUBLIC;
GRANT  ALL ON SEQUENCE file_file_id_seq TO admin;
GRANT  ALL ON SEQUENCE file_file_id_seq TO xtrole;
