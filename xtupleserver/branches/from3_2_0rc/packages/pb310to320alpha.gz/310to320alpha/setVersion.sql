
SELECT setMetric('OpenMFGServerVersion', '3.2.0Alpha');

