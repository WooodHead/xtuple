REVOKE ALL ON SEQUENCE urlinfo_url_id_seq FROM PUBLIC;
GRANT  ALL ON SEQUENCE urlinfo_url_id_seq TO admin;
GRANT  ALL ON SEQUENCE urlinfo_url_id_seq TO xtrole;
