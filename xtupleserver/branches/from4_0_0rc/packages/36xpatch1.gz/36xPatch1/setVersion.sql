SELECT setMetric('ServerPatchVersion', COALESCE((SELECT metric_value FROM metric WHERE metric_name = 'ServerPatchVersion'), '') || '1');

