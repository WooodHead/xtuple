
SELECT setMetric('OpenMFGServerVersion', '3.1.0Beta2');

