
ALTER TABLE ipsitem DROP CONSTRAINT ipsitem_ipsitem_ipshead_id_key1;

