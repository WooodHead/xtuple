SELECT setMetric('ServerVersion', '.3.8.0-3.8.1');

