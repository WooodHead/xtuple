SELECT setMetric('ServerVersion', '.3.8.0RC2-3.8.0');

