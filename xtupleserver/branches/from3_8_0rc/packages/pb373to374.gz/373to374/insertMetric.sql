BEGIN;

INSERT INTO metric (metric_name, metric_value) values ('CreditTaxDiscount', 't');

COMMIT;

