SELECT setMetric('ServerVersion', '3.7.4');

