SELECT dropIfExists('TRIGGER','itemlocFixTrigger');
SELECT dropIfExists('FUNCTION','_itemlocFixTrigger()');
