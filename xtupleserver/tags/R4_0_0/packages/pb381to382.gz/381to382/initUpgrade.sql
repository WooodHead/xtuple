SELECT setMetric('ServerVersion', '.3.8.1-3.8.2');

