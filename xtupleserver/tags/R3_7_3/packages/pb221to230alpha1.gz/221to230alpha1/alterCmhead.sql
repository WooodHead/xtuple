
ALTER TABLE cmhead ADD COLUMN cmhead_rahead_id integer;

