ALTER TABLE taxauth ADD taxauth_accnt_id INTEGER REFERENCES accnt(accnt_id);
