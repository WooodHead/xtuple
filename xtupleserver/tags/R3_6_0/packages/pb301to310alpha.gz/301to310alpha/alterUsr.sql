
ALTER TABLE usr ADD UNIQUE (usr_username);

