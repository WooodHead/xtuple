SELECT createColumn('public',  'locale', 'locale_weight_scale',
                    'integer', '2',      FALSE);
