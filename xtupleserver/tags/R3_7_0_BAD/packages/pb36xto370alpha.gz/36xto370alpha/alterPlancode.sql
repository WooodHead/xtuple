ALTER TABLE plancode ADD COLUMN plancode_mrpexcp_resched BOOLEAN;
ALTER TABLE plancode ADD COLUMN plancode_mrpexcp_delete BOOLEAN;
