
DROP FUNCTION getMetric(TEXT);
DROP FUNCTION getMetricBoolean(TEXT);

