SELECT setMetric('InvcNumberGeneration', 'A');
