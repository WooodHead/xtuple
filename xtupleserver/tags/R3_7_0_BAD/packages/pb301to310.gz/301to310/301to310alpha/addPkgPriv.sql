INSERT INTO priv
  (priv_module, priv_name, priv_descrip)
VALUES
  ('System', 'MaintainPackages', 'Can Install and Uninstall Packages.');
INSERT INTO priv
  (priv_module, priv_name, priv_descrip)
VALUES
  ('System', 'ViewPackages', 'Can View installed Packages.');
