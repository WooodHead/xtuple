INSERT INTO priv
  (priv_module, priv_name, priv_descrip)
VALUES
  ('System', 'fixACL', 'Can fix Access Control List problems at the database level.');
