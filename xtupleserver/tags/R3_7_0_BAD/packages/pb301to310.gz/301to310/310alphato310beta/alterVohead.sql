
ALTER TABLE vohead ADD COLUMN vohead_misc BOOLEAN;

