
ALTER TABLE locale ADD COLUMN locale_percent_scale INTEGER DEFAULT 2;

