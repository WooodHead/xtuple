
ALTER TABLE cohead DROP COLUMN cohead_labelform_id;


