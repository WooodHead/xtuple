SELECT setMetric('ServerVersion', '3.6.0Beta');

