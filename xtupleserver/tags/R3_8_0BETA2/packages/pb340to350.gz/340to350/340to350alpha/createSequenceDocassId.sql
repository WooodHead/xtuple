-- Sequence: docass_docass_id_seq

-- DROP SEQUENCE docass_docass_id_seq;

--CREATE SEQUENCE docass_docass_id_seq
--  INCREMENT 1
--  MINVALUE 1
--  MAXVALUE 9223372036854775807
--  START 20
--  CACHE 1;
GRANT ALL ON TABLE docass_docass_id_seq TO xtrole;
