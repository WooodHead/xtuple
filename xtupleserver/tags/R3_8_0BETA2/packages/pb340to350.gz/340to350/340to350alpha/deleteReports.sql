DELETE FROM report WHERE report_name = 'BalanceSheet' AND report_grade = 0;
DELETE FROM report WHERE report_name = 'IncomeStatement' AND report_grade = 0;