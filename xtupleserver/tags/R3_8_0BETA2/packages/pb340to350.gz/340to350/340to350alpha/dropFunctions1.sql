
SELECT dropifexists('FUNCTION','postarmemo(integer)');
SELECT dropifexists('FUNCTION','applyarmemotobalance(integer)');
