SELECT dropIfExists('TABLE', 'obsolete_poitemcol');
