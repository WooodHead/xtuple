SELECT dropIfExists('TABLE', 'backup_ccpay');
SELECT dropIfExists('TABLE', 'backup_payco');
