delete from report where report_name = 'VoucheringEditList' and report_grade = 0;
delete from report where report_name = 'BillingEditList' and report_grade = 0;
delete from report where report_name = 'SalesJournal' and report_grade = 0;
delete from report where report_name = 'SalesJournalByDate' and report_grade = 0;
delete from report where report_name = 'CreditMemoJournal' and report_grade = 0;
delete from report where report_name = 'PayablesJournal' and report_grade = 0;
delete from report where report_name = 'CheckJournal' and report_grade = 0;
delete from report where report_name = 'CashReceiptsJournal' and report_grade = 0;