SELECT dropIfExists('FUNCTION', 'deletecontact(integer)', 'public');
