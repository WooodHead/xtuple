
ALTER TABLE quitem ADD COLUMN quitem_promdate DATE;


