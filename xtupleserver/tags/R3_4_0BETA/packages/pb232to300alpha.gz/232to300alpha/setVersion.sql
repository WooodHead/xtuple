
SELECT setMetric('OpenMFGServerVersion', '3.0.0Alpha');

