ALTER TABLE comment ADD FOREIGN KEY (comment_cmnttype_id) REFERENCES cmnttype(cmnttype_id);
