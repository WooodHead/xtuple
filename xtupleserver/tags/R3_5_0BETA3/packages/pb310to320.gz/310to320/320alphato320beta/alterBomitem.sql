
ALTER TABLE bomitem ADD COLUMN bomitem_ref TEXT;

