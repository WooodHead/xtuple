
-- just do an update to get the trigger to fire
UPDATE period SET period_initial=true WHERE period_initial=true;

