SELECT dropIfExists('function', 'freightDetail(text,integer)');
