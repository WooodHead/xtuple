
SELECT dropifexists('TRIGGER','apopenTrigger');

