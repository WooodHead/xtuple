
UPDATE metric SET metric_name = 'ServerPatchVersionPrevious' WHERE metric_name='ServerPatchVersion';
INSERT INTO metric (metric_name, metric_value)
VALUES('ServerPatchVersion', COALESCE((SELECT metric_value FROM metric WHERE metric_name='ServerPatchVersionPrevious'), '') || '1');
DELETE FROM metric WHERE metric_name='ServerPatchVersionPrevious';
