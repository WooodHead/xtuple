
ALTER TABLE cmhead DROP COLUMN cmhead_taxtype_id;

