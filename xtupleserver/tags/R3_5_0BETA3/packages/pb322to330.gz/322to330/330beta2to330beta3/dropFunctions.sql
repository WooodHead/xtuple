
SELECT dropIfExists('FUNCTION', 'scrapWoMaterial(INTEGER, NUMERIC, BOOLEAN)');

