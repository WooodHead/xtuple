
ALTER TABLE womatl ADD COLUMN womatl_scrapvalue NUMERIC(16,6) DEFAULT 0;

