INSERT INTO priv (priv_module, priv_name, priv_descrip)
VALUES
  ('System', 'MaintainEmployeeGroups', 'Can Change or Create Employee Groups.');

INSERT INTO priv (priv_module, priv_name, priv_descrip)
VALUES
  ('System', 'ViewEmployeeGroups', 'Can view Employee Group records.');
