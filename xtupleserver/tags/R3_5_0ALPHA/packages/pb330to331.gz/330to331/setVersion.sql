
SELECT setMetric('ServerVersion', '3.3.1');

