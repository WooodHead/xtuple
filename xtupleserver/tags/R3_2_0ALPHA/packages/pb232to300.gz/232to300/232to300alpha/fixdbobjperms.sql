-- need to load resetdbobjperms from dbscripts/functions first
SELECT resetDBObjPerms();
