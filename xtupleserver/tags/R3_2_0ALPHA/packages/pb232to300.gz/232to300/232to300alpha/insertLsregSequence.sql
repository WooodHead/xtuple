
INSERT INTO orderseq (orderseq_name,orderseq_number,orderseq_table,orderseq_numcol)
VALUES('LsRegNumber',1,'lsreg','lsreg_number');

