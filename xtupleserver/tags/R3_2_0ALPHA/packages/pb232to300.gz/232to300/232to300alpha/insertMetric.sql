
INSERT INTO metric (metric_name, metric_value) values ('RecurringInvoiceBuffer', '7');

