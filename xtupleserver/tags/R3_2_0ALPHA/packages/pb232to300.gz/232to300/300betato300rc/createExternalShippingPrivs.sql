INSERT INTO priv (priv_module, priv_name, priv_descrip)
VALUES
  ('Inventory', 'MaintainExternalShipping', 'Can Change or Create External Shipping Records.');
