ALTER TABLE grppriv DROP CONSTRAINT grppriv_grppriv_priv_id_fkey;
