
--Remove this table that was never implemented
DROP TABLE itematr;

