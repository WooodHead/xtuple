REVOKE ALL ON SEQUENCE labeldef_labeldef_id_seq FROM public;
GRANT  ALL ON SEQUENCE labeldef_labeldef_id_seq TO xtrole;
