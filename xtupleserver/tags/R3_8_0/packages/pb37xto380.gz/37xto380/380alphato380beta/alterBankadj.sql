ALTER TABLE bankadj ADD COLUMN bankadj_curr_rate NUMERIC;
