delete from report where report_name = 'IncidentsByCRMAccount' and report_grade = 0;
delete from report where report_name = 'TodoByUserAndIncident' and report_grade = 0;