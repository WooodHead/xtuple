SELECT dropIfExists('FUNCTION',
                    'createAROpenItem(integer, text, character, text, date, date, numeric, text)',
                    'public');
