INSERT INTO source (source_module, source_name, source_descrip)
            VALUES ('CRM',         'PSPCT',     'Prospect'),
                   ('Sales',       'SR',        'Sales Rep'),
                   ('Accounting',  'TAXAUTH',   'Tax Authority'),
                   ('System',      'USR',       'User');
