alter table invchead add column invchead_void boolean default false;
