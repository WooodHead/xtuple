SELECT dropIfExists('CONSTRAINT', 'invhist_invhist_costmethod_check');
