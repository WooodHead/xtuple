SELECT dropIfExists('CONSTRAINT', 'imageass_imageass_image_id_fkey', 'public');
