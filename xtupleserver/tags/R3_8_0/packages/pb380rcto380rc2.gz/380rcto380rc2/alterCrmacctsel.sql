ALTER TABLE crmacctsel ADD crmacctsel_mrg_crmacct_number BOOL NOT NULL DEFAULT FALSE;
