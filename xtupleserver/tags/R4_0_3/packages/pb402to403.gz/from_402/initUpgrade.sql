SET search_path TO 'public';

SELECT setMetric('ServerVersion', '.4.0.2-4.0.3');

