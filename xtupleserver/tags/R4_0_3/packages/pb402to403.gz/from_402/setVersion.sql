SELECT setMetric('ServerVersion', '4.0.3');
