create index aropen_aropen_docnumber_idx on aropen (aropen_docnumber);
