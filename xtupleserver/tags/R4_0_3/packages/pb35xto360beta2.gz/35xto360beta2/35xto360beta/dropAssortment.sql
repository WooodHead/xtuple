-- Never implemented
SELECT dropIfExists('TABLE', 'asshead');
SELECT dropIfExists('TABLE', 'assitem');

SELECT dropIfExists('FUNCTION', 'copyAssortment(INTEGER, INTEGER)');
