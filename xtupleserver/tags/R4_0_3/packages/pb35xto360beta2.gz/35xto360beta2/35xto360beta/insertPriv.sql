INSERT INTO priv (priv_module, priv_name, priv_descrip) VALUES ('Accounting','DeletePostedJournals','Can delete posted Standard Journals and Journal Entries');
INSERT INTO priv (priv_module, priv_name, priv_descrip) VALUES ('Accounting','EditPostedJournals','Can edit posted Journal Entries');
INSERT INTO priv (priv_module, priv_name, priv_descrip) VALUES ('Accounting','ViewSubLedger','Can view sub ledger transactions');
INSERT INTO priv (priv_module, priv_name, priv_descrip) VALUES ('Accounting','PostSubLedger','Can post sub ledger transactions');

