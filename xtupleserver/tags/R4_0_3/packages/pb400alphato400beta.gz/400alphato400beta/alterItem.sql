alter table item alter column item_picklist set default true;
alter table item alter column item_type set default 'R';
alter table item alter column item_prodweight set default 0;
alter table item alter column item_packweight set default 0;
alter table item alter column item_exclusive set default false;
alter table item alter column item_maxcost set default 0;
alter table item alter column item_config set default false;
alter table item alter column item_tax_recoverable set default false;

