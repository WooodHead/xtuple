alter table accnt drop column accnt_closedpost cascade;

