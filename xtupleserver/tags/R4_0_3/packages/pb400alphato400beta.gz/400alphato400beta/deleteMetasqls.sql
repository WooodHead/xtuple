DELETE FROM metasql
 WHERE metasql_group = 'customer'
   AND metasql_name  = 'detail'
   AND metasql_grade = 0;
