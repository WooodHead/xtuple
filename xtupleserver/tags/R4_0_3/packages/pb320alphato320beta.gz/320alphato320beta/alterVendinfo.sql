
ALTER TABLE vendinfo ADD COLUMN vend_ediemailhtml BOOLEAN DEFAULT false NOT NULL;

