
CREATE INDEX usrpref_userpref_name_idx ON usrpref (usrpref_name);

