SELECT setMetric('ServerVersion', '4.1.0Beta');
