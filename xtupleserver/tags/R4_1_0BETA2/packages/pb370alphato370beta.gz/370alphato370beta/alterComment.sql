
ALTER TABLE comment ADD COLUMN comment_public BOOLEAN;

