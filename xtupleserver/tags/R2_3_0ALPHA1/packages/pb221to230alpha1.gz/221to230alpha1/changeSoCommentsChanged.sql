UPDATE evnttype
SET evnttype_name = 'SoNotesChanged'
WHERE (evnttype_name='SoCommentsChanged');
