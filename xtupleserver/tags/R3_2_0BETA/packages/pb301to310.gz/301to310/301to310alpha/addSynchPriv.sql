INSERT INTO priv
  (priv_module, priv_name, priv_descrip)
VALUES
  ('Accounting', 'SynchronizeCompanies',
   'Can run company trial balance synchronization utility.');
