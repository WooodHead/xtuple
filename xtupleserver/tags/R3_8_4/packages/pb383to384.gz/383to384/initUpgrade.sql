SELECT setMetric('ServerVersion', '.3.8.3-3.8.4');

