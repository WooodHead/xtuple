SELECT setMetric('ServerVersion', '.3.8.2-3.8.3');

