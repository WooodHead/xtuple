SELECT setMetric('ServerVersion', '.4.0.0Alpha-4.0.0Beta');
