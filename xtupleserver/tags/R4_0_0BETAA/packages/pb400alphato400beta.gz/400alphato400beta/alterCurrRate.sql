alter table curr_rate alter column curr_rate type numeric(16,8);
