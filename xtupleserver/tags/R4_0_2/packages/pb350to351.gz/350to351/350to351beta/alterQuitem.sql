ALTER TABLE quitem ADD COLUMN quitem_dropship boolean DEFAULT false;
