DELETE FROM report WHERE (report_name = 'InventoryHistoryByItem' AND report_grade = 0);
DELETE FROM report WHERE (report_name = 'InventoryHistoryByOrderNumber' AND report_grade = 0);
DELETE FROM report WHERE (report_name = 'InventoryHistoryByParameterList' AND report_grade = 0);
DELETE FROM report WHERE (report_name = 'InventoryHistoryByWarehouse' AND report_grade = 0);
DELETE FROM report WHERE (report_name = 'InventoryHistoryByClassCode' AND report_grade = 0);
DELETE FROM report WHERE (report_name = 'InventoryHistoryByItemGroup' AND report_grade = 0);
DELETE FROM report WHERE (report_name = 'InventoryHistoryByPlannerCode' AND report_grade = 0);
