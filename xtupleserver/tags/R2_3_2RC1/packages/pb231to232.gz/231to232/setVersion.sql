
SELECT setMetric('OpenMFGServerVersion', '2.3.2');

