
DROP FUNCTION setnextshipmentnumber(integer);

