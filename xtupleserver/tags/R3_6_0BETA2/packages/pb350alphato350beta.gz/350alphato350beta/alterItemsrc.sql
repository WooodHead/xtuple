ALTER TABLE itemsrc ADD COLUMN itemsrc_upccode text;
