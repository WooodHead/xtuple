
ALTER TABLE shiptoinfo DROP COLUMN shipto_labelform_id;

