
SELECT setMetric('ServerVersion', '3.5.6');

