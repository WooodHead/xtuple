
-- Item Comment

--DROP VIEW api.itemcomment;
CREATE VIEW api.itemcomment
AS 
   SELECT 
     item_number::varchar(100) AS item_number,
     cmnttype_name AS type,
     comment_date AS date,
     comment_user AS username,
     comment_text AS text
   FROM item, cmnttype, comment
   WHERE ((comment_source='I')
   AND (comment_source_id=item_id)
   AND (comment_cmnttype_id=cmnttype_id));

GRANT ALL ON TABLE api.salesordercomment TO openmfg;
COMMENT ON VIEW api.salesordercomment IS 'Item Comments';

--Rules

CREATE OR REPLACE RULE "_INSERT" AS
    ON INSERT TO api.itemcomment DO INSTEAD

  INSERT INTO comment (
    comment_date,
    comment_source,
    comment_source_id,
    comment_user,
    comment_cmnttype_id,
    comment_text
    )
  VALUES (
    COALESCE(NEW.date,now()),
    'IS',
    getItemId(NEW.item_number),
    COALESCE(NEW.username,current_user),
    getCmntTypeId(NEW.type),
    NEW.text);

CREATE OR REPLACE RULE "_UPDATE" AS
    ON UPDATE TO api.itemcomment DO INSTEAD NOTHING;

CREATE OR REPLACE RULE "_DELETE" AS
    ON DELETE TO api.itemcomment DO INSTEAD NOTHING;

