
DROP FUNCTION postcccredit(INTEGER);

