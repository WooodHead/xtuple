
SELECT setMetric('OpenMFGServerVersion', '3.2.1Beta');

