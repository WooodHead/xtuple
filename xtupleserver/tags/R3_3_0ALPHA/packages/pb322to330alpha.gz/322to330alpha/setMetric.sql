
SELECT setMetric('VerboseCommentList','t');


