select dropifexists('FUNCTION', 'getflcoldata(int,int)');
select dropifexists('FUNCTION', 'getflcoldata(char,int[],bool)');
select dropifexists('TYPE', 'flcoldata');
CREATE TYPE flcoldata AS (
  flcoldata_column  	INTEGER,
  flcoldata_start   	DATE,
  flcoldata_end        DATE
);
