INSERT INTO evnttype (evnttype_name, evnttype_descrip, evnttype_module) VALUES ('CashReceiptPosted', 'A Cash Receipt has been posted', 'G/L');
