ALTER TABLE prospect ADD CONSTRAINT prospect_prospect_number_key UNIQUE (prospect_number);
