INSERT INTO priv (priv_module, priv_name, priv_descrip) VALUES ('System','MaintainTranslations','User is allowed to maintain/download translations to their local computer.');
INSERT INTO priv (priv_module, priv_name, priv_descrip) VALUES ('System','MaintainDictionaries','User is allowed to maintain/download spell check dictionaries to their local computer.');

