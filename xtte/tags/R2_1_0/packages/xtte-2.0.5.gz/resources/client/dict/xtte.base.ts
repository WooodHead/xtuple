<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>configureCRM</name>
    <message>
        <location filename="../scripts/configureCRM.js" line="20"/>
        <source>Project Labor And Overhead:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dspTimeExpenseHistory</name>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="20"/>
        <source>Sheet #</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="21"/>
        <source>Employee #</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="22"/>
        <source>Work Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="23"/>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="49"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="24"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="25"/>
        <source>Project#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="26"/>
        <source>Project Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="27"/>
        <source>Task#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="28"/>
        <source>Task Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="29"/>
        <source>Cust.#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="30"/>
        <source>Cust. Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="31"/>
        <source>PO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="32"/>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="57"/>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="33"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="34"/>
        <source>Qty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="35"/>
        <source>Billable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="37"/>
        <source>Ext.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="39"/>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="87"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="41"/>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="88"/>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="47"/>
        <source>Start Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="48"/>
        <source>End Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="50"/>
        <source>Employee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="51"/>
        <source>Employee Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="52"/>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="53"/>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="54"/>
        <source>Customer Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="55"/>
        <source>Customer Type Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="56"/>
        <source>Customer Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="58"/>
        <source>Item Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="59"/>
        <source>Class Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="60"/>
        <source>Class Code Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="71"/>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="76"/>
        <source>View...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="84"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="85"/>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/dspTimeExpenseHistory.js" line="86"/>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspTimeExpenseHistory.ui" line="21"/>
        <source>Time and Expense History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspTimeExpenseHistory.ui" line="32"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspTimeExpenseHistory.ui" line="39"/>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspTimeExpenseHistory.ui" line="46"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspTimeExpenseHistory.ui" line="86"/>
        <source>Time Sheet Items</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>employee</name>
    <message>
        <location filename="../scripts/employee.js" line="17"/>
        <source>Contractor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <location filename="../scripts/initMenu.js" line="17"/>
        <source>Initialize te failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="18"/>
        <source>Failed to initialize the te package. This functionality may not work correctly. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="34"/>
        <source>Initialize xtmfg failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="35"/>
        <source>Failed to initialize the te package. This functionality may not work correctly. %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="45"/>
        <source>Time and Expense...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="53"/>
        <source>Time and Expense History</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>item</name>
    <message>
        <location filename="../scripts/item.js" line="110"/>
        <source>Can not save item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/item.js" line="111"/>
        <source>You must select a G/L Account or an expense account for Project Expense Items.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>project</name>
    <message>
        <location filename="../scripts/project.js" line="16"/>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/project.js" line="20"/>
        <source>Gantt...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/project.js" line="180"/>
        <source>You must enter a valid Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/project.js" line="181"/>
        <source>Invalid Date</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>projectGantt</name>
    <message>
        <location filename="../uiforms/projectGantt.ui" line="24"/>
        <source>Project Gantt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/projectGantt.ui" line="54"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/projectGantt.ui" line="57"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>task</name>
    <message>
        <location filename="../scripts/task.js" line="16"/>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tebilling</name>
    <message>
        <location filename="../uiforms/tebilling.ui" line="21"/>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tebilling.ui" line="56"/>
        <source>Use specified billing rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tebilling.ui" line="68"/>
        <source>Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tebilling.ui" line="123"/>
        <source>Use Specified item</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tecustomer</name>
    <message>
        <location filename="../uiforms/tecustomer.ui" line="21"/>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tecustomer.ui" line="45"/>
        <source>Use specified billing rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tecustomer.ui" line="57"/>
        <source>Rate:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>teexpense</name>
    <message>
        <location filename="../uiforms/teexpense.ui" line="33"/>
        <source>Expense Item Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/teexpense.ui" line="62"/>
        <source>Allow use as Expense Item on Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/teexpense.ui" line="90"/>
        <source>Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/teexpense.ui" line="100"/>
        <source>Expense Category</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheet</name>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="38"/>
        <source>Line #</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="39"/>
        <source>Sheet Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="40"/>
        <source>Work Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="41"/>
        <source>Project#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="42"/>
        <source>Project Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="43"/>
        <source>Task#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="44"/>
        <source>Task Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="45"/>
        <source>Cust.#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="46"/>
        <source>Cust. Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="47"/>
        <source>PO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="48"/>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="49"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="56"/>
        <source>Billable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="57"/>
        <source>Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="58"/>
        <source>Extended</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="60"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="130"/>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="134"/>
        <source>View...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="137"/>
        <source>Delete...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="146"/>
        <source>Are you sure you want to delete this line?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="214"/>
        <source>Employee Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="217"/>
        <source>Site Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="220"/>
        <source>Week Ending Date Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="224"/>
        <source>Processing Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="296"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="51"/>
        <location filename="../scripts/timeExpenseSheet.js" line="297"/>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="50"/>
        <source>Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="298"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="311"/>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="312"/>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="313"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="323"/>
        <source>Delete Sheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="324"/>
        <source>&lt;p&gt;Are you sure you want to cancel this sheet and discard all your changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="27"/>
        <source>Time and Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="38"/>
        <source>Sheet #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="45"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="84"/>
        <source>S&amp;heet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="92"/>
        <source>Week of Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="121"/>
        <source>Site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="150"/>
        <source>Employee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="199"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="209"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="222"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="235"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheet.js" line="52"/>
        <location filename="../uiforms/timeExpenseSheet.ui" line="264"/>
        <source>Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheet.ui" line="281"/>
        <source>Print on Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheetItem</name>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="46"/>
        <source>Prev</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="47"/>
        <location filename="../scripts/timeExpenseSheetItem.js" line="257"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="136"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="153"/>
        <source>No task found. A default task will be added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="154"/>
        <source>task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="188"/>
        <source>Upate Rate?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="189"/>
        <source>&lt;p&gt;Would you like to update the existing rate?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="255"/>
        <location filename="../scripts/timeExpenseSheetItem.js" line="652"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="287"/>
        <source>Work Date Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="290"/>
        <source>Project Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="293"/>
        <source>Item Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="296"/>
        <source>Task Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="299"/>
        <source>Billing of negative amounts is not supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="303"/>
        <source>Processing Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="309"/>
        <source>The system only supports vouchering positive expense quantities.  Do you want to save anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="355"/>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="125"/>
        <source>Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="356"/>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="135"/>
        <source>Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="364"/>
        <source>Qty:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="365"/>
        <source>Unit Cost:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="534"/>
        <location filename="../scripts/timeExpenseSheetItem.js" line="575"/>
        <source>Unsaved Changed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="535"/>
        <location filename="../scripts/timeExpenseSheetItem.js" line="576"/>
        <source>&lt;p&gt;You have made some changes which have not yet been saved!
Would you like to save them now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="696"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheetItem.js" line="697"/>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="21"/>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="27"/>
        <source>Time and Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="55"/>
        <source>  Cust. PO#:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="145"/>
        <source>Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="162"/>
        <source>Employee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="180"/>
        <source>Billable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="207"/>
        <source>timedtl_rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="259"/>
        <source>Prepaid (not reimbursable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="316"/>
        <source>Week of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="336"/>
        <source>Work Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="346"/>
        <source>Project #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="402"/>
        <source>Task:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="439"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="473"/>
        <source>Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="479"/>
        <source>Task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="504"/>
        <source>Planned Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="524"/>
        <source>Planned Expense:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="537"/>
        <source>Actual Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="550"/>
        <source>Actual Expense:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="598"/>
        <source>Employee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="610"/>
        <source>Day Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="623"/>
        <source>Sheet Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="636"/>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="646"/>
        <source>Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="692"/>
        <source>Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="714"/>
        <source>Sheet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheetItem.ui" line="731"/>
        <source>Line #:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheets</name>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="37"/>
        <source>Sheet#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="38"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="39"/>
        <source>Employee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="40"/>
        <location filename="../uiforms/timeExpenseSheets.ui" line="172"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="42"/>
        <source>Extended</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="43"/>
        <source>Invoiced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="44"/>
        <source>Vouchered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="45"/>
        <source>Posted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="65"/>
        <location filename="../uiforms/timeExpenseSheets.ui" line="306"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="70"/>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="74"/>
        <source>View...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="77"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="85"/>
        <location filename="../uiforms/timeExpenseSheets.ui" line="290"/>
        <source>Approve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="92"/>
        <source>Unapprove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="99"/>
        <location filename="../uiforms/timeExpenseSheets.ui" line="274"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="111"/>
        <location filename="../uiforms/timeExpenseSheets.ui" line="230"/>
        <source>Invoice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="118"/>
        <location filename="../uiforms/timeExpenseSheets.ui" line="237"/>
        <source>Voucher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="125"/>
        <location filename="../uiforms/timeExpenseSheets.ui" line="244"/>
        <source>Post Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="301"/>
        <location filename="../scripts/timeExpenseSheets.js" line="375"/>
        <source>Setup Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="302"/>
        <location filename="../scripts/timeExpenseSheets.js" line="376"/>
        <source>No Labor and Overhead Account defined in CRM Setup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="309"/>
        <location filename="../scripts/timeExpenseSheets.js" line="383"/>
        <source>Post Time Sheet for </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="310"/>
        <location filename="../scripts/timeExpenseSheets.js" line="384"/>
        <source> to Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="413"/>
        <source>This action can not be undone.  Are you sure you want to delete this sheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="428"/>
        <source>This action can not be undone. Are you sure you want to close this sheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="511"/>
        <location filename="../uiforms/timeExpenseSheets.ui" line="185"/>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="512"/>
        <location filename="../uiforms/timeExpenseSheets.ui" line="192"/>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="513"/>
        <location filename="../uiforms/timeExpenseSheets.ui" line="178"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="514"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="515"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="516"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="570"/>
        <source>It appears that your current user isn&apos;t an active employee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="574"/>
        <source>Permissions Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="575"/>
        <source>You do not have permissions to maintain time and expense entries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="585"/>
        <source>Earliest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/timeExpenseSheets.js" line="586"/>
        <source>Latest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="33"/>
        <source>Time and Expense Sheets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="88"/>
        <source>Employees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="96"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="123"/>
        <source>Selected:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="157"/>
        <source>Week of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="223"/>
        <source>When Processing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="266"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="269"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="277"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="282"/>
        <source>Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="285"/>
        <source>Process Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="293"/>
        <source>Approve All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="298"/>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="301"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/timeExpenseSheets.ui" line="309"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>xtte</name>
    <message>
        <location filename="../scripts/xtte.js" line="30"/>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
