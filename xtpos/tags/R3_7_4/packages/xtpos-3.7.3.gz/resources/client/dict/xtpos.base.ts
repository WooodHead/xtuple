<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>cashRegister</name>
    <message>
        <location filename="../scripts/cashRegister.js" line="63"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="64"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="65"/>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="66"/>
        <source>Cust#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="67"/>
        <source>Contact#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="68"/>
        <source>Hnfc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="69"/>
        <source>First</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="70"/>
        <source>Middle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="71"/>
        <source>Last</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="72"/>
        <source>Suffix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="73"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="74"/>
        <source>Voice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="75"/>
        <source>Alternate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="76"/>
        <source>Fax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="77"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="78"/>
        <source>Web</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="79"/>
        <source>Cont. Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="80"/>
        <source>Address#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="81"/>
        <source>Address1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="82"/>
        <source>Address2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="83"/>
        <source>Address3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="84"/>
        <source>City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="85"/>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="86"/>
        <source>Postal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="87"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="88"/>
        <source>Addr. Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="89"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="90"/>
        <source>Sales Rep.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="91"/>
        <source>Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="92"/>
        <source>Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="93"/>
        <source>Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="94"/>
        <source>Tax Zone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="95"/>
        <source>Subtotal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="96"/>
        <source>Tax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="97"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="293"/>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/cashRegister.js" line="294"/>
        <source>Could not initialize printing system for multiple reports.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="21"/>
        <source>Cash Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="41"/>
        <source>Site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="58"/>
        <source>Terminal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="75"/>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="104"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="117"/>
        <source>Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="140"/>
        <source>Pending Sales:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="172"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="198"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="208"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="218"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="228"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="254"/>
        <source>Search...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="320"/>
        <source>Maintain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="328"/>
        <source>Opened:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="361"/>
        <source>Action:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="393"/>
        <source>&amp;Post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="420"/>
        <source>Opening Balance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="443"/>
        <source>Cash Sales:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="469"/>
        <source>Current Balance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="495"/>
        <source>Credit Card Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="521"/>
        <source>Total Sales:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="547"/>
        <source>Check Sales:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="593"/>
        <source>Bank Transfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="599"/>
        <source>Account:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="633"/>
        <source> Amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="671"/>
        <source>Deposit Checks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="702"/>
        <source>Adjustment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="711"/>
        <source>Amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="769"/>
        <source>New Balance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="809"/>
        <source>Notes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="836"/>
        <source>Print Receipt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegister.ui" line="859"/>
        <source>Options...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>cashRegisters</name>
    <message>
        <location filename="../uiforms/cashRegisters.ui" line="21"/>
        <source>Cash Registers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegisters.ui" line="45"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegisters.ui" line="56"/>
        <source>Cash Register Terminals:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegisters.ui" line="85"/>
        <source>&amp;Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/cashRegisters.ui" line="95"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>configureRetail</name>
    <message>
        <location filename="../uiforms/configureRetail.ui" line="21"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/configureRetail.ui" line="35"/>
        <source>Next Retail Sale #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/configureRetail.ui" line="63"/>
        <source>Default Customer for Retail Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/configureRetail.ui" line="101"/>
        <source>Disable Choosing Customer at Cash Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/configureRetail.ui" line="111"/>
        <source>Tax Zone Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/configureRetail.ui" line="122"/>
        <source>Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/configureRetail.ui" line="132"/>
        <source>Customer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dspDetailedRegisterHistory</name>
    <message>
        <location filename="../uiforms/dspDetailedRegisterHistory.ui" line="21"/>
        <source>Detailed Register History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspDetailedRegisterHistory.ui" line="46"/>
        <source>All Terminals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspDetailedRegisterHistory.ui" line="56"/>
        <source>Selected:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspDetailedRegisterHistory.ui" line="122"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspDetailedRegisterHistory.ui" line="132"/>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspDetailedRegisterHistory.ui" line="142"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspDetailedRegisterHistory.ui" line="192"/>
        <source>Results:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dspRegisterHistory</name>
    <message>
        <location filename="../uiforms/dspRegisterHistory.ui" line="21"/>
        <source>Register History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspRegisterHistory.ui" line="61"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspRegisterHistory.ui" line="68"/>
        <source>&amp;Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspRegisterHistory.ui" line="75"/>
        <source>&amp;Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspRegisterHistory.ui" line="123"/>
        <source>Register Posting Detail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/dspRegisterHistory.ui" line="153"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <location filename="../scripts/initMenu.js" line="14"/>
        <location filename="../scripts/initMenu.js" line="31"/>
        <source>Initialize xtpos failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="15"/>
        <source>Failed to initialize the xtpos package. This functionality may not work correctly. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/initMenu.js" line="32"/>
        <source>Failed to initialize the xtpos package. This functionality may not work correctly. %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>payment</name>
    <message>
        <location filename="../scripts/payment.js" line="291"/>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/payment.js" line="292"/>
        <source>Could not initialize printing system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="21"/>
        <source>Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="60"/>
        <source>Subtotal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="70"/>
        <source>Tax:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="80"/>
        <source>Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="152"/>
        <source>Cash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="158"/>
        <location filename="../uiforms/payment.ui" line="209"/>
        <location filename="../uiforms/payment.ui" line="505"/>
        <source>Amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="197"/>
        <source>Credit Card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="229"/>
        <source>Credit Card Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="243"/>
        <source>Master Card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="248"/>
        <source>Visa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="253"/>
        <source>American Express</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="258"/>
        <source>Discover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="272"/>
        <source>Expiration Month:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="291"/>
        <source>01</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="296"/>
        <source>02</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="301"/>
        <source>03</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="306"/>
        <source>04</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="311"/>
        <source>05</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="316"/>
        <source>06</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="321"/>
        <source>07</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="326"/>
        <source>08</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="331"/>
        <source>09</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="336"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="341"/>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="346"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="354"/>
        <source> Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="376"/>
        <source>Expiration Year:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="392"/>
        <source>2009</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="397"/>
        <source>2010</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="402"/>
        <source>2011</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="407"/>
        <source>2012</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="412"/>
        <source>2013</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="417"/>
        <source>2014</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="422"/>
        <source>2015</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="427"/>
        <source>2016</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="432"/>
        <source>2017</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="437"/>
        <source>2018</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="442"/>
        <source>2019</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="447"/>
        <source>2020</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="455"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="468"/>
        <source>CVV:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="491"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="522"/>
        <source>Document #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="585"/>
        <source>Change Due:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="647"/>
        <source>Balance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="654"/>
        <source>Paid:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="705"/>
        <source>Print Receipt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/payment.ui" line="731"/>
        <source>Options...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>retailCustomer</name>
    <message>
        <location filename="../uiforms/retailCustomer.ui" line="26"/>
        <source>Cash Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailCustomer.ui" line="53"/>
        <source>Customer #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailCustomer.ui" line="89"/>
        <source>Customer Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailCustomer.ui" line="110"/>
        <source>Billing Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailCustomer.ui" line="209"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailCustomer.ui" line="216"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>retailSale</name>
    <message>
        <location filename="../scripts/retailSale.js" line="634"/>
        <source>This action will delete all listed items.  Are you sure you want to do this?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="21"/>
        <source>Retail Sale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="41"/>
        <source>Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="61"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="75"/>
        <source>Closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="101"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="104"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="117"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="120"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="133"/>
        <source>&amp;Customer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="170"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="180"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="189"/>
        <source>Billing Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="291"/>
        <source>&amp;Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="321"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="324"/>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="337"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="357"/>
        <source>Receipt Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="377"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="416"/>
        <source>Qty:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="434"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="456"/>
        <source>Unit Price:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="469"/>
        <source>Extended:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="574"/>
        <source>&amp;Detail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="608"/>
        <location filename="../uiforms/retailSale.ui" line="721"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="669"/>
        <source>Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="679"/>
        <source>Sales Rep:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="689"/>
        <source>Terminal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="699"/>
        <source>Site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="711"/>
        <source>Tax Zone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="798"/>
        <source>Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="839"/>
        <source>Subtotal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="862"/>
        <source>Tax:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="885"/>
        <source>Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSale.ui" line="924"/>
        <source>&amp;Payment...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>retailSaleSearch</name>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="20"/>
        <source>Retail Sale Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="40"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="46"/>
        <source>Sales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="59"/>
        <source>Quotes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="72"/>
        <source>Returns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="85"/>
        <source>Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="133"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="140"/>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="156"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="183"/>
        <source>Search:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="237"/>
        <source>Results:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="257"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSaleSearch.ui" line="267"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>retailSite</name>
    <message>
        <location filename="../scripts/retailSite.js" line="70"/>
        <source>Bank Account </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSite.js" line="70"/>
        <source> is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSite.js" line="90"/>
        <source>Terminal </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSite.js" line="90"/>
        <source> already exists on site </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSite.js" line="135"/>
        <source>You must select a site.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSite.js" line="138"/>
        <source>You must select a valid Asset account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSite.js" line="141"/>
        <source>You must select a valid Adjustment account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSite.js" line="144"/>
        <source>You must select a valid Check Clearing account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSite.js" line="147"/>
        <source>You must add at least one bank account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSite.js" line="150"/>
        <source>You must add at least one terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="21"/>
        <source>Retail Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="40"/>
        <source>Site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="82"/>
        <source>Tax Zone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="123"/>
        <source>Quotes Expire in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="136"/>
        <source>30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="143"/>
        <source>days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="172"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="179"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="218"/>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="224"/>
        <source>Asset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="254"/>
        <source>Adjustment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="284"/>
        <source>Check Clearing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="315"/>
        <source>Bank Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="348"/>
        <location filename="../uiforms/retailSite.ui" line="474"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="358"/>
        <location filename="../uiforms/retailSite.ui" line="484"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="398"/>
        <source>Bank Account:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="408"/>
        <source>[ select a bank account ]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSite.ui" line="444"/>
        <source>Terminals</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>retailSites</name>
    <message>
        <location filename="../scripts/retailSites.js" line="32"/>
        <source>Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSites.js" line="33"/>
        <source>Tax Zone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSites.js" line="34"/>
        <source>Quote Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSites.js" line="35"/>
        <source>Asset Acct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSites.js" line="36"/>
        <source>Adjust Acct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSites.js" line="37"/>
        <source>Clearing Acct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/retailSites.js" line="58"/>
        <source>Are you sure you want to delete this retail site?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSites.ui" line="21"/>
        <source>Retail Sites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSites.ui" line="61"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSites.ui" line="68"/>
        <source>&amp;Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSites.ui" line="79"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSites.ui" line="89"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSites.ui" line="99"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/retailSites.ui" line="109"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>setup</name>
    <message>
        <location filename="../scripts/setup.js" line="18"/>
        <source>Retail Sites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripts/setup.js" line="23"/>
        <source>Retail Site</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
