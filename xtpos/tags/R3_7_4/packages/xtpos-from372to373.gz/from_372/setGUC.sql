SET standard_conforming_strings TO false;
