COMMENT ON TABLE te.teemprate IS 'This table is deprecated.  Use the core emp table instead.';
