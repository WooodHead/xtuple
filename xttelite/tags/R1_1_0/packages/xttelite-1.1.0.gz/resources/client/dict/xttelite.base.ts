<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>te</name>
    <message>
        <location filename="../uiforms/te.ui" line="27"/>
        <source>Time and Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="46"/>
        <source>Sheet #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="53"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="79"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="86"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="102"/>
        <source>&amp;Header Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="117"/>
        <source>Sheet Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="159"/>
        <source>Site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="188"/>
        <source>Employee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="220"/>
        <source>Print on Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="242"/>
        <source>&amp;Line Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="272"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="288"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="304"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="320"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/te.ui" line="349"/>
        <source>Sheet Notes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tebilling</name>
    <message>
        <location filename="../uiforms/tebilling.ui" line="21"/>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tebilling.ui" line="45"/>
        <source>Default Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tebilling.ui" line="72"/>
        <source>Item:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tebillingemp</name>
    <message>
        <location filename="../uiforms/tebillingemp.ui" line="21"/>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tebillingemp.ui" line="45"/>
        <source>Default Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tebillingemp.ui" line="72"/>
        <source>Item:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>teexpense</name>
    <message>
        <location filename="../uiforms/expense.ui" line="33"/>
        <source>Expense Item Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/expense.ui" line="45"/>
        <source>Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/expense.ui" line="132"/>
        <source>Expense Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/expense.ui" line="142"/>
        <source>Delete Expense Item Setup</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tesheet</name>
    <message>
        <location filename="../uiforms/tesheet.ui" line="33"/>
        <source>Open Sheets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="65"/>
        <source>All Employees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="72"/>
        <source>Selected:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="126"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="133"/>
        <source>Query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="140"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="177"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="187"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="197"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="207"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="224"/>
        <source>Approve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="241"/>
        <source>Exp Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/tesheet.ui" line="251"/>
        <source>Time Report</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>time_expense</name>
    <message>
        <location filename="../uiforms/time_expense.ui" line="26"/>
        <location filename="../uiforms/time_expense.ui" line="32"/>
        <source>Time and Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="47"/>
        <source>Sheet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="64"/>
        <source>Line #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="100"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="110"/>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="131"/>
        <source>Sheet Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="148"/>
        <source>Work Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="196"/>
        <source>Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="206"/>
        <source>Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="216"/>
        <source>Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="233"/>
        <source>Employee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="248"/>
        <source>timedtl_hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="284"/>
        <source>timedtl_rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="361"/>
        <source>Prepaid (not reimbursable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="371"/>
        <source>Billable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="424"/>
        <source>  Cust. PO#:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="478"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="491"/>
        <source>Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="504"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="517"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="546"/>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="575"/>
        <source>Project #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="596"/>
        <source>Task:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="615"/>
        <source>public</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="618"/>
        <source>prjtask</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="621"/>
        <source>prjtask_id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="624"/>
        <source>prjtask_name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="676"/>
        <source>Budget/Actual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="682"/>
        <source>Planned Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="699"/>
        <source>Actual Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="729"/>
        <source>Planned Expense:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="746"/>
        <source>Actual Expense:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../uiforms/time_expense.ui" line="767"/>
        <source>Notes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
