GRANT ALL ON TABLE te.tehead_tehead_id_seq TO xtrole;
GRANT ALL ON TABLE te.tehead_tehead_id_seq TO "admin";

GRANT ALL ON TABLE te.timesheet_seq TO "admin";
GRANT ALL ON TABLE te.timesheet_seq TO xtrole;

GRANT ALL ON TABLE te.teitem_teitem_id_seq TO "admin";
GRANT ALL ON TABLE te.teitem_teitem_id_seq TO xtrole;

GRANT ALL ON TABLE te.temetric_metric_id_seq TO "admin";
GRANT ALL ON TABLE te.temetric_metric_id_seq TO xtrole;

GRANT ALL ON TABLE te.teprj_teprj_id_seq TO "admin";
GRANT ALL ON TABLE te.teprj_teprj_id_seq TO xtrole;

GRANT ALL ON TABLE te.cons_seq TO "admin";
GRANT ALL ON TABLE te.cons_seq TO xtrole;
