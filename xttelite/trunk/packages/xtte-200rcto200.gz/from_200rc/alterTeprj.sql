ALTER TABLE te.teprj DROP CONSTRAINT teprj_teprj_cust_id_key;
